主要内容集中在main.cpp中。

本示例将16Khz采样的PCM数据先编码为AMR，再调用函数将AMR编码转化为GSM编码，再进行GSM解码。

脚本AddHead.sh为输出的文件output.pcm添加wav文件头，便于播放。
